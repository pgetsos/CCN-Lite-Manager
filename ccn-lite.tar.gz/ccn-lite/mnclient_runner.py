# -*- coding: utf-8 -*-
import zmq
import msgpack
from zmq.eventloop.ioloop import IOLoop
from zmq.eventloop.ioloop import PeriodicCallback # TODO you can find other way probably
from mnclient import MNClient, mn_request
from logging import getLogger

from config import *

__license__ = """
    This file is part of Dedalus.

    Dedalus is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Dedalus is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Dedalus.  If not, see <http://www.gnu.org/licenses/>.
"""

__author__ = 'Esmerald Aliaj'
__email__ = 'esmeraldaliai@yahoo.gr'

_LOG = getLogger(__name__)
_DLOG = getLogger('dedalus_logger')


class ClientRunner(MNClient):

    def __init__(self, context, endpoint, service):
        MNClient.__init__(self, context, endpoint, service)
        self.sent = []
        self.current_num = 0
        return

    def on_message(self, msg):
        recieved = msgpack.unpackb(msg, encoding='utf-8')
        _LOG.info("Received: %s" % repr(recieved))
        # TODO see message parts
        _LOG.info("percentage of nums received : %s" % str(len(self.sent) / self.current_num))

        # IOLoop.instance().stop()
         # 1st part is empty
        msg.pop(0)
        # 2nd part is protocol version
        # TODO: version check
        proto = msg.pop(0)
        if proto != CLIENT_PROTO:
            pass
            # TODO raise exception. add this functionality to other classes too

        (service, cmd, wid_str, reply) = msg

        if cmd == b'\x50':
            self.sent.remove(reply)
        else:
            # invalid message
            # ignored
            pass

        return recieved


    def on_timeout(self):
        print('TIMEOUT!')
        _LOG.info("Timeout! No response from broker.")
        # IOLoop.instance().stop()
        return

    def flood_worker(self):
        self.current_num += 1
        self.request([b'hs15', msgpack.packb(self.current_num)], 2000)
        self.sent.append(self.current_num)

def run(address):
    context = zmq.Context()
    client = ClientRunner(context, address, b"echo")
    hb_check_timer = PeriodicCallback(client.flood_worker(), 1000)
    hb_check_timer.start()
    try:
        IOLoop.instance().start()
        client.shutdown()
    except KeyboardInterrupt:
        _LOG.info("Interrupt received, stopping!")
    finally:
        # clean up
        client.shutdown()
        context.term()

if __name__ == '__main__':
    run("tcp://127.0.0.1:5555")

run("tcp://127.0.0.1:5555")

# def run(address):
#     try:
#         context = zmq.Context()
#         socket = context.socket(zmq.REQ)
#         socket.setsockopt(zmq.LINGER, 0)
#         socket.connect(address)
#         current_num = 0
#         recieved_well = 0
#         hb_check_timer = PeriodicCallback(flood_worker(socket, current_num, recieved_well), 1000)
#         hb_check_timer.start()
#         socket.close()
#     except KeyboardInterrupt:
#         _LOG.info("Interrupt received, stopping.")
#     finally:
#         # clean up
#         context.term()