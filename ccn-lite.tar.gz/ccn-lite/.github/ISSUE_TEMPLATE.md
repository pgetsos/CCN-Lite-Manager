#### Description
<!--
Example: Cannot build CCN-lite for RIOT.
-->

#### Steps to reproduce the issue
<!--
Try to describe as precisely as possible here the steps required to reproduce
the issue. Here you can also describe your hardware configuration, the network
setup, etc.
-->

#### Expected results
<!--
Example: CCN-lite builds for RIOT.
-->

#### Actual results
<!--
Please paste or specifically describe the actual output.
-->

#### Versions
<!--
Operating system: Mac OSX, Linux, Vagrant VM
Build environment: GCC, CLang versions, etc.
-->

<!-- Thanks for contributing! -->

