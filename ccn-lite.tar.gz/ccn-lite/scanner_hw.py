# -*- coding: utf-8 -*-
import threading
import iperf3
import msgpack
import psutil
from scapy.all import *
from scapy.layers.inet import ICMP, IP, Ether
from collections import Counter
from config import *
from scanner_babel import BabelScanner

__license__ = """
    This file is part of Dedalus.

    Dedalus is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Dedalus is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Dedalus.  If not, see <http://www.gnu.org/licenses/>.
"""

__author__ = 'Esmerald Aliaj'
__email__ = 'esmeraldaliai@yahoo.gr'

ROUTING_PROTOCOL = b'rp01'  # This must be set dynamically


class HWTraffic(object):
    # TODO: document this class
    def __init__(self):
        self.thread_stop = threading.Event()
        self._worker_funcs = {MSG_SENDTRAFFIC: self.send_traffic,
                              MSG_STOPSENDINGTRAFFIC: self.stop_sending_traffic,
                              MSG_MEASUREBANDWIDTH: self.measure_bandwidth
                              }

    def run(self, cmd, arg):
        # TODO: FIX THIS
        if cmd == MSG_SENDTRAFFIC:
            data = msgpack.unpackb(arg.pop(0))
            fnc = self._worker_funcs[cmd]
            interface = data['interface']
            destination = data['destination']
            waittime = data['waittime']
            return fnc(interface, destination, waittime)
        elif cmd == MSG_STOPSENDINGTRAFFIC:
            fnc = self._worker_funcs[cmd]
            return fnc()
        elif cmd == MSG_MEASUREBANDWIDTH:
            data = msgpack.unpackb(arg.pop(0))
            bind_address = data['bind_address']
            mode = data['mode']
            fnc = self._worker_funcs[cmd]
            return fnc(bind_address, mode)
        return None

    @staticmethod
    def send_empty_traffic(stop_event, interface="lo", destination="localhost", waittime=0):
        # needs to run as root
        # also will never stop
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.IPPROTO_RAW)
        s.bind((interface, 0))
        pe = Ether() / IP(dst=destination) / ICMP()
        data = pe.build()
        while not stop_event.is_set():
            time.sleep(int(waittime))
            s.send(data)
        pass

    def send_traffic(self, interface="lo", destination="localhost", waittime=0):
        self.thread_stop.clear()
        thread_data_traffic = threading.Thread(target=self.send_empty_traffic,
                                               args=(self.thread_stop, interface, destination, waittime))
        thread_data_traffic.deamon = True
        thread_data_traffic.start()

    def stop_sending_traffic(self):
        self.thread_stop.set()
        pass

    def measure_bandwidth(self, bind_address, mode='server'):
        thread_bandwidth = threading.Thread(target=self.measure_bandwidth_tcp,
                                            args=(bind_address, mode))
        thread_bandwidth.deamon = True
        thread_bandwidth.start()

    @staticmethod
    def measure_bandwidth_tcp(bind_address, mode='server', port=6969, duration=1, bulksize=1234,
                              num_streams=10, zerocopy=True, verbose=False, reverse=False):
        if mode == 'client':
            client = iperf3.Client()
            client.duration = duration
            # client.bind_address = bind_address
            client.server_hostname = bind_address
            client.port = port
            client.bulksize = bulksize
            client.num_streams = num_streams
            client.zerocopy = zerocopy
            client.verbose = verbose
            client.reverse = reverse
            result = client.run()
        else:
            server = iperf3.Server()
            server.bind_address = bind_address
            server.port = 6969
            server.verbose = False
            result = server.run()
        return result


class HWScanner(object):
    def __init__(self):
        self._protocols = {ROUTING_BABEL: BabelScanner}
        self.protocol_scanner = self._protocols[ROUTING_PROTOCOL]()
        self._worker_funcs = {MSG_ECHO: self.echo,
                              MSG_CPUPERCENT: self.cpu_percent,
                              MSG_CPUTIMES: self.cpu_times,
                              MSG_CPUTIMESPERCENT: self.cpu_times_percent,
                              MSG_CPUCOUNT: self.cpu_count,
                              MSG_CPUSTATS: self.cpu_stats,
                              MSG_NETIOCOUNTERS: self.net_io_counters,
                              MSG_NETCONNECTIONS: self.net_connections,
                              MSG_NETIFADDRS: self.net_if_addrs,
                              MSG_NETIFSTATS: self.net_if_stats,
                              MSG_BOOTTIME: self.boot_time,
                              MSG_MEMORYINFO: self.memory_info,
                              MSG_MEMORYPERCENT: self.memory_percent,
                              MSG_CONNECTIONS: self.connections,
                              MSG_DUMP: self.dump
                              }
        self.current_interface = self.protocol_scanner.get_current_interface()
        self.traffic_generator = HWTraffic()

    def run(self, cmd, args):
        data = None
        if args:
            data = msgpack.unpackb(args)
        if cmd in self._worker_funcs:
            fnc = self._worker_funcs[cmd]
            if data:
                return fnc(*data)
            return fnc()
        return None

    def get_interface(self):
        """Returns the current interface used by the routing protocol.
        """
        return self.current_interface

    @staticmethod
    def cpu_percent(interval=1, percpu=True):
        """Return a float representing the current system-wide CPU utilization as a percentage. When interval is > 0.0 
        compares system CPU times elapsed before and after the interval (blocking). When interval is 0.0 or None 
        compares system CPU times elapsed since last call or module import, returning immediately. That means the first 
        time this is called it will return a meaningless 0.0 value which you are supposed to ignore. In this case it is 
        recommended for accuracy that this function be called with at least 0.1 seconds between calls. When percpu is 
        True returns a list of floats representing the utilization as a percentage for each CPU. First element of the 
        list refers to first CPU, second element to second CPU and so on. The order of the list is consistent across 
        calls.
        """
        return psutil.cpu_percent(interval=interval, percpu=percpu)

    @staticmethod
    def cpu_times():
        """Return system CPU times as a named tuple. Every attribute represents the seconds the CPU has spent in the 
        given mode. The attributes availability varies depending on the platform.
        """
        return psutil.cpu_times()

    @staticmethod
    def cpu_times_percent(interval=1, percpu=False):
        """Same as cpu_percent() but provides utilization percentages for each specific CPU time as is returned by 
        psutil.cpu_times(percpu=True). interval and percpu arguments have the same meaning as in cpu_percent().
        """
        return psutil.cpu_times_percent(interval=interval, percpu=percpu)

    @staticmethod
    def cpu_count(logical=False):
        """Return the number of logical CPUs in the system (same as os.cpu_count() in Python 3.4). If logical is False 
        return the number of physical cores only (hyper thread CPUs are excluded). Return None if undetermined.
        """
        return psutil.cpu_count(logical=logical)

    @staticmethod
    def cpu_stats():
        """Return various CPU statistics as a named tuple
        """
        return psutil.cpu_stats()

    @staticmethod
    def cpu_freq():
        """Return CPU frequency as a nameduple including current, min and max frequencies expressed in Mhz. On Linux 
        current frequency reports the real-time value, on all other platforms it represents the nominal “fixed” value. 
        If percpu is True and the system supports per-cpu frequency retrieval (Linux only) a list of frequencies is 
        returned for each CPU, if not, a list with a single element is returned. If min and max cannot be determined 
        they are set to 0.
        """
        return psutil.cpu_freq()

    @staticmethod
    def virtual_memory():
        """Return statistics about system memory usage as a named tuple including the following fields, expressed in bytes.
        """
        return psutil.virtual_memory()

    @staticmethod
    def swap_memory():
        """Return system swap memory statistics as a named tuple
        """
        return psutil.swap_memory()

    @staticmethod
    def disk_partitions():
        """Return all mounted disk partitions as a list of named tuples including device, mount point and filesystem 
        type, similarly to “df” command on UNIX. If all parameter is False it tries to distinguish and return physical 
        devices only (e.g. hard disks, cd-rom drives, USB keys) and ignore all others (e.g. memory partitions such as 
        /dev/shm). Note that this may not be fully reliable on all systems (e.g. on BSD this parameter is ignored). 
        Named tuple’s fstype field is a string which varies depending on the platform. On Linux it can be one of the 
        values found in /proc/filesystems (e.g. 'ext3' for an ext3 hard drive o 'iso9660' for the CD-ROM drive). On 
        Windows it is determined via GetDriveType and can be either "removable", "fixed", "remote", "cdrom", "unmounted" 
        or "ramdisk". On OSX and BSD it is retrieved via getfsstat(2).
        """
        return psutil.disk_partitions()

    @staticmethod
    def disk_usage(directory='/'):
        """Return disk usage statistics about the given path as a named tuple including total, used and free space 
        expressed in bytes, plus the percentage usage. OSError is raised if path does not exist. 
        """
        return psutil.disk_usage(directory)

    @staticmethod
    def disk_io_counters(perdisk=True):
        """Return system-wide disk I/O statistics as a named tuple
        """
        return psutil.disk_io_counters(perdisk=perdisk)

    @staticmethod
    def net_io_counters(pernic=True):
        """Return system-wide network I/O statistics as a named tuple
        """
        return psutil.net_io_counters(pernic=pernic)

    @staticmethod
    def net_connections():
        """Return system-wide socket connections as a list of named tuples.
        """
        return psutil.net_connections()

    @staticmethod
    def net_if_addrs():
        """Return the addresses associated to each NIC (network interface card) installed on the system as a dictionary 
        whose keys are the NIC names and value is a list of named tuples for each address assigned to the NIC.
        """
        return psutil.net_if_addrs()

    @staticmethod
    def net_if_stats():
        """Return information about each NIC (network interface card) installed on the system as a dictionary whose keys 
        are the NIC names and value is a named tuple.
        """
        return psutil.net_if_stats()

    @staticmethod
    def sensors_temperatures(fahrenheit=False):
        """Return hardware temperatures. Each entry is a named tuple representing a certain hardware temperature sensor 
        (it may be a CPU, an hard disk or something else, depending on the OS and its configuration). All temperatures 
        are expressed in celsius unless fahrenheit is set to True. If sensors are not supported by the OS an empty dict 
        is returned.
        """
        return psutil.sensors_temperatures(fahrenheit=fahrenheit)

    @staticmethod
    def sensors_fans():
        """Return hardware fans speed. Each entry is a named tuple representing a certain hardware sensor fan. Fan speed 
        is expressed in RPM (rounds per minute). If sensors are not supported by the OS an empty dict is returned.
        """
        return psutil.sensors_fans()

    @staticmethod
    def sensors_battery():
        """Return battery status information as a named tuple including the following values. If no battery is installed 
        or metrics can’t be determined None is returned.
        """
        return psutil.sensors_battery()

    @staticmethod
    def users():
        """Return users currently connected on the system as a list of named tuples.
        """
        return psutil.users()

    @staticmethod
    def boot_time():
        """Return the system boot time expressed in seconds since the epoch.
        """
        return psutil.boot_time()

    @staticmethod
    def pids():
        """Return a list of current running PIDs. To iterate over all processes and avoid race conditions process_iter() 
        should be preferred.
        """
        return psutil.pids()

    @staticmethod
    def pid_exists(pid):
        """Check whether the given PID exists in the current process list. This is faster than doing pid in 
        psutil.pids() and should be preferred.
        """
        return psutil.pid_exists(pid)

    @staticmethod
    def pid():
        """The process PID. This is the only (read-only) attribute of the class.
        """
        return psutil.Process().pid()

    @staticmethod
    def ppid():
        """The process parent PID. On Windows the return value is cached after first call. Not on POSIX because ppid may 
        change if process becomes a zombie.
        """
        return psutil.Process().ppid()

    @staticmethod
    def name():
        """The process name. On Windows the return value is cached after first call. Not on POSIX because the process 
        name may change.
        """
        return psutil.Process().name()

    @staticmethod
    def exe():
        """The process executable as an absolute path. On some systems this may also be an empty string. The return 
        value is cached after first call.
        """
        return psutil.Process().exe()

    @staticmethod
    def cmdline():
        """The command line this process has been called with as a list of strings. The return value is not cached 
        because the cmdline of a process may change.
        """
        return psutil.Process().cmdline()

    @staticmethod
    def environ():
        """The environment variables of the process as a dict. Note: this might not reflect changes made after the 
        process started.
        """
        return psutil.Process().environ()

    @staticmethod
    def create_time():
        """The process creation time as a floating point number expressed in seconds since the epoch, in UTC. The return 
        value is cached after first call.
        """
        return psutil.Process().create_time()

    @staticmethod
    def status():
        """The current process status as a string.
        """
        return psutil.Process().status()

    @staticmethod
    def cwd():
        """The process current working directory as an absolute path.
        """
        return psutil.Process().cwd()

    @staticmethod
    def username():
        """The name of the user that owns the process. On UNIX this is calculated by using real process uid.
        """
        return psutil.Process().username()

    @staticmethod
    def uids():
        """The real, effective and saved user ids of this process as a named tuple. This is the same as os.getresuid() 
        but can be used for any process PID.
        """
        return psutil.Process().uids()

    @staticmethod
    def gids():
        """The real, effective and saved group ids of this process as a named tuple. This is the same as os.getresgid() 
        but can be used for any process PID.
        """
        return psutil.Process().gids()

    @staticmethod
    def terminal():
        """The terminal associated with this process, if any, else None. This is similar to “tty” command but can be 
        used for any process PID.
        """
        return psutil.Process().terminal()

    @staticmethod
    def nice(value=None):
        """Get or set process niceness (priority). On UNIX this is a number which usually goes from -20 to 20. The 
        higher the nice value, the lower the priority of the process.
        """
        return psutil.Process().nice(value)

    @staticmethod
    def io_counters():
        """Return process I/O statistics as a named tuple.
        """
        return psutil.Process().io_counters()

    @staticmethod
    def num_ctx_switches():
        """The number voluntary and involuntary context switches performed by this process (cumulative).
        """
        return psutil.Process().num_ctx_switches()

    @staticmethod
    def num_fds():
        """The number of file descriptors currently opened by this process (non cumulative).
        """
        return psutil.Process().num_fds()

    @staticmethod
    def num_handles():
        """The number of handles currently used by this process (non cumulative).
        """
        return psutil.Process().num_handles()

    @staticmethod
    def num_threads():
        """The number of threads currently used by this process (non cumulative).
        """
        return psutil.Process().num_threads()

    @staticmethod
    def threads():
        """Return threads opened by process as a list of named tuples including thread id and thread CPU times (user/system).
        """
        return psutil.Process().threads()

    @staticmethod
    def process_cpu_times(pid):
        """Return a (user, system, children_user, children_system) named tuple representing the accumulated process 
        time, in seconds (see explanation). On Windows and OSX only user and system are filled, the others are set to 0. 
        This is similar to os.times() but can be used for any process PID.
        """
        return psutil.Process(pid).cpu_times

    @staticmethod
    def process_cpu_percent(pid, interval=None):
        """Return a float representing the process CPU utilization as a percentage which can also be > 100.0 in case of 
        a process running multiple threads on different CPUs. When interval is > 0.0 compares process times to system 
        CPU times elapsed before and after the interval (blocking). When interval is 0.0 or None compares process times 
        to system CPU times elapsed since last call, returning immediately. That means the first time this is called it 
        will return a meaningless 0.0 value which you are supposed to ignore. In this case is recommended for accuracy 
        that this function be called a second time with at least 0.1 seconds between calls.
        """
        return psutil.Process(pid).cpu_percent(interval=interval)

    @staticmethod
    def process_cpu_num(pid):
        """Return what CPU this process is currently running on. The returned number should be <= psutil.cpu_count(). It 
        may be used in conjunction with psutil.cpu_percent(percpu=True) to observe the system workload distributed 
        across multiple CPUs.
        """
        return psutil.Process(pid).cpu_num()

    @staticmethod
    def memory_info():
        """Return a named tuple with variable fields depending on the platform representing memory information about the 
        process. The “portable” fields available on all platforms are rss and vms. All numbers are expressed in bytes.
        """
        return psutil.Process().memory_info()

    @staticmethod
    def memory_percent(memtype="rss"):
        """Compare process memory to total physical system memory and calculate process memory utilization as a 
        percentage. memtype argument is a string that dictates what type of process memory you want to compare against.
        """
        return psutil.Process().memory_percent(memtype=memtype)

    @staticmethod
    def memory_maps(grouped=True):
        """Return process’s mapped memory regions as a list of named tuples whose fields are variable depending on the 
        platform. This method is useful to obtain a detailed representation of process memory usage as explained here 
        (the most important value is “private” memory). If grouped is True the mapped regions with the same path are 
        grouped together and the different memory fields are summed. If grouped is False each mapped region is shown as 
        a single entity and the named tuple will also include the mapped region’s address space (addr) and permission 
        set (perms).
        """
        return psutil.Process().memory_maps(grouped=grouped)

    @staticmethod
    def children(recursive=False):
        """Return the children of this process as a list of Process objects, preemptively checking whether PID has been 
        reused. If recursive is True return all the parent descendants.
        """
        return psutil.Process().children(recursive=recursive)

    @staticmethod
    def open_files():
        """Return regular files opened by process as a list of named tuples.
        """
        return psutil.Process().open_files()

    @staticmethod
    def connections(kind="inet"):
        """Return socket connections opened by process as a list of named tuples.
        """
        return psutil.Process().connections(kind=kind)

    @staticmethod
    def is_running(pid):
        """Return whether the current process is running in the current process list. This is reliable also in case the 
        process is gone and its PID reused by another process.
        """
        return psutil.Process(pid).is_running()

    @staticmethod
    def terminate_process(pid):
        """Terminate the process with SIGTERM signal preemptively checking whether PID has been reused.
        """
        return psutil.Process(pid).terminate()

    @staticmethod
    def wait_process(pid, timeout=None):
        """Wait for process termination and if the process is a children of the current one also return the exit code, 
        else None. On Windows there’s no such limitation (exit code is always returned). If the process is already 
        terminated immediately return None instead of raising NoSuchProcess. If timeout is specified and process is 
        still alive raise TimeoutExpired exception. It can also be used in a non-blocking fashion by specifying 
        timeout=0 in which case it will either return immediately or raise TimeoutExpired.
        """
        return psutil.Process(pid).wait(timeout=timeout)

    @staticmethod
    def kill_process(pid):
        """Kill the current process by using SIGKILL signal preemptively checking whether PID has been reused.
        """
        return psutil.Process(pid).kill()

    @staticmethod
    def resume_process(pid):
        """Resume process execution with SIGCONT signal preemptively checking whether PID has been reused.
        """
        return psutil.Process(pid).resume()

    @staticmethod
    def suspend_process(pid):
        """Suspend process execution with SIGSTOP signal preemptively checking whether PID has been reused.
        """
        return psutil.Process(pid).suspend()

    @staticmethod
    def echo(echo_message):
        """Return echo message
        """
        return echo_message

    def dump(self):
        """Return system info in bulk.
        """
        return {'net_io_counters': self.net_io_counters(),
                'memory_percent': self.memory_percent(),
                'cpu_percent': self.cpu_percent(),
                'boot_time': self.boot_time(),
                'routing_dump': self.protocol_scanner.get_routing_info(),
                'edge_traffic': list(self.traffic_per_connection())}

    def send_traffic(self, interface, destination, waittime):
        """Send random data packets to a worker.
        """
        self.traffic_generator.send_traffic(interface, destination, waittime)
        return

    def stop_sending(self):
        """Stop sending traffic.
        """
        self.traffic_generator.stop_sending_traffic()
        return

    def traffic_per_connection(self, sample_interval=1, hosts_limit=10):
        try:
            traffic = Counter()
            hosts = {}
            interface = self.current_interface

            def bandwidth_format(num):
                for x in ['', 'k', 'M', 'G', 'T']:
                    if num < 1024.:
                        return "%3.1f %sB" % (num, x)
                    num /= 1024.
                return "%3.1f PB" % num

            def traffic_monitor_callback(pkt):
                if IP in pkt:
                    pkt = pkt[IP]
                    traffic.update({tuple(sorted(map(atol, (pkt.src, pkt.dst)))): pkt.len})

            sniff(iface=interface, prn=traffic_monitor_callback, store=False,
                  timeout=sample_interval)

            for (h1, h2), total in traffic.most_common(hosts_limit):
                h1, h2 = map(ltoa, (h1, h2))
                for host in (h1, h2):
                    if host not in hosts:
                        try:
                            rhost = socket.gethostbyaddr(host)
                            hosts[host] = rhost[0]
                        except IndexError:
                            hosts[host] = None

                h1 = "%s (%s)" % (hosts[h1], h1) if hosts[h1] is not None else h1
                h2 = "%s (%s)" % (hosts[h2], h2) if hosts[h2] is not None else h2
                yield {'bandwidth': bandwidth_format(float(total) / sample_interval), 'from': h1, 'to': h2}
        except:
            yield "Traffic information gathering not permitted by host!"
