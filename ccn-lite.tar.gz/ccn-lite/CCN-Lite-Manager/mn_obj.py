class MN_object(object):

    def _create_stream(self):
        pass
