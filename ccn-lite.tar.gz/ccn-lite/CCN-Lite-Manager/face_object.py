class FaceObject:
    ip = "192.168.1.1"
    nodenum = 1
